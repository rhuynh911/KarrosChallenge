import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//-------------------------------------------------------
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
 
public class SeleniumScript{
public static void main(String[] args) throws InterruptedException{
		System.setProperty("webdriver.chrome.driver", "/Users/huynhthanhvinh/Downloads/Selenium/chromedriver");
		WebDriver driver = new ChromeDriver();
		
		// Configure some parameters for automation test
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		// Initialize automation session
		driver.get("http://ktvn-test.s3-website.us-east-1.amazonaws.com/signin");
		
		//Login with username and password
		driver.findElement(By.cssSelector("#formHorizontalEmail")).click();
		driver.findElement(By.cssSelector("#formHorizontalEmail")).sendKeys("admin@test.com");
		driver.findElement(By.cssSelector("#formHorizontalPassword")).click();
		driver.findElement(By.cssSelector("#formHorizontalPassword")).sendKeys("test123");
		Thread.sleep(2000);
		driver.findElement(By.cssSelector(".col-login__btn")).click();
		Thread.sleep(5000);
		
		// Change request status to "Approved", Date Submitted all default is 2019
		driver.findElement(By.cssSelector(".table-header-col-status")).click();
		driver.findElement(By.cssSelector(".table-header-col-status")).click();
		Thread.sleep(2000);
				
		WebElement mytable = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div/div/div[1]/div[2]/table/tbody"));	
		List<WebElement> rows_table = mytable.findElements(By.tagName("tr"));
		// Get ONE first XPath after making request above
		String xpath = rows_table.get(0).getAttribute("xpath");
		System.out.println("ONE XPath to return the request is " + xpath);
		Thread.sleep(3000);
		
		//Do filtering Student Access Request with INACTIVE
		driver.findElement(By.cssSelector(".fa-search")).click();
		driver.findElement(By.cssSelector("#formControlsSelect")).click();
		driver.findElement(By.cssSelector("#formControlsSelect")).sendKeys("Inactive");
		driver.findElement(By.cssSelector(".ct-modal-footer > .btn-filter")).click();
		Thread.sleep(1000);
		
		//Do sorting of the first name column
		driver.findElement(By.cssSelector(".sort-column:nth-child(6)")).click();
		driver.findElement(By.cssSelector(".sort-column:nth-child(6)")).click();
		Thread.sleep(4000);
		
		// Log out
		driver.findElement(By.cssSelector("#basic-nav-dropdown")).click();
		driver.findElement(By.cssSelector(".open > .dropdown-menu a")).click();
		Thread.sleep(2000);
		
		// Terminate automation session
		driver.close();
		
		//--------------------------------------------------------------------------------------
		//The API endpoint - GET
		try {
			URL url = new URL("https://my-json-server.typicode.com/typicode/demo/posts/1");
	        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
	        conn.setRequestMethod("GET");
	        conn.connect();
	        
	        //Getting the response code
            int responsecode = conn.getResponseCode();
            if (responsecode != 200) {
                throw new RuntimeException("HttpResponseCode: " + responsecode);
            } else {
            	String inline = "";
            	Scanner scanner = new Scanner(url.openStream());
            	 //Write all the JSON data into a string using a scanner
                while (scanner.hasNext()) {
                    inline += scanner.nextLine();
                }
                //Close the scanner
                scanner.close();
                System.out.println("API Get result is: " + inline);
            }
	        
		} catch (Exception e) {
			e.printStackTrace();
		}
		//--------------------------------------------------------------------------------------
	} 
}